sap.ui.define([
	"com/mindset/analyzerdetail/AppAnalyzerDetail/test/unit/controller/App.controller"
], function () {
	"use strict";
});